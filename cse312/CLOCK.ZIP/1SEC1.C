#include <unistd.h>
#include <stdio.h>
 
main()
  {
  while (1)
    {
    putchar((char) 10);
    sleep(1);
     }
  }

