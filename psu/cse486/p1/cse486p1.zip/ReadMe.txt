/*

	Jason F Smith
	CSE/EE 486   Project 1   Readme.txt


	Some OpenGL/Win32 code for this project was modified/copied from
	the Win32 OpenGL tutorials at http://nehe.gamedev.net.

	These functions are commented as 'Taken from: NeHe' if copied
	directly.  If taken and then modified, it is commented as
	'Modified from: NeHe'

	This copied/modified code has nothing to do with the assignment
	other than to enhance the GUI for demonstration purposes.  All
	code dealing with the RAW image and subsequent calculations on
	this image was written by Jason F Smith.

*/