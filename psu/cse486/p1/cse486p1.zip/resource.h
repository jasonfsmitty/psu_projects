//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Control.rc
//
#define IDD_MAIN_DIALOG                 101
#define IDC_EDIT_FILENAME               1000
#define IDC_OPENDIALOG                  1001
#define IDC_WIDTH                       1002
#define IDC_HEIGHT                      1003
#define IDC_FOREGROUND                  1004
#define IDC_LOADBUTTON                  1005
#define IDC_ROBOTSIZE                   1006
#define IDC_STARTX                      1007
#define IDC_STARTY                      1008
#define IDC_ENDX                        1009
#define IDC_ENDY                        1010
#define IDC_DISPLAYORIGINAL             1011
#define IDC_DISPLAYMEDIAL               1012
#define IDC_DISPLAYMEDIALOVERLAY        1013
#define IDC_DISPLAYPATH                 1014
#define IDC_DISPLAYSAVE                 1015
#define IDEXIT                          1016
#define IDC_RESET                       1017
#define IDC_BUTTON1                     1018
#define IDC_DISPLAYCLOSE                1018
#define IDC_PROCESS_ROBOT               1019

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
