/*
	Jason F Smith
	CSE 485    Project 1

	Just declares the function.
*/

#ifndef CLEAN_PATH_H
#define CLEAN_PATH_H

struct Position;

void CleanRobotPath( Position s, Position d );

#endif