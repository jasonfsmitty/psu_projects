/*--------------------------------------------------------------------------+
	Jason F Smith
	CSE 486

	Just declare the function.
 +--------------------------------------------------------------------------*/


#ifndef CALC_PATH_H
#define CALC_PATH_H


bool CalcRobotPath( void );


#endif