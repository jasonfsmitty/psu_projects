#include <iostream.h>
#include <stdio.h>
#include "filesys.h"
# include <assert.h>
//---------------------------------------------------------------------------
// test program 2 
// 
//  Stress test
//  Creates a large number of files of finite size
//
//--------------------------------------------------------------------------- 
main ( int argc , char **argv ) 
{
  char buf[1000] , ch , fname[13];
  int i , j , l , fp , result , createcount = 0 , writecount = 0 , flag = 1 ;   
  int temp1 , temp2 , k ;
   
  // Init the filesystem
       fs_init () ;

  // Fill up the buffer with data
       for ( i = 0 ; i < 1000 ; i ++ ) buf[i] =  'A' + (i % 52) ;

  // Outer loop - big enough
       for ( k = 0 ; k < 10000  && flag ; k ++ ) {
	 // Restart counters
	      temp1 = temp2 = 0 ;

	 // Create files in batches of 10
	      for ( i = 0 ; i < 10 ; i ++ ) {
		sprintf ( fname , "%d_%d.txt" , k , i ) ;
		result = fs_create ( fname ) ; 
		if ( result == 0 ) 
		  { cout << "File creation failed" << endl ; flag = 0 ; break ; }
		createcount ++ ;
	      }
    
	 // Write some data 
	      for ( j = 0 ; j < i ; j ++ ) {
		sprintf ( fname , "%d_%d.txt" , k , j ) ;
		fp = fs_open ( fname , "w" ) ;
		result = fs_write ( fp , buf , 500 ) ;
		fs_close ( fp ) ;
		fs_delete(fname);
		if ( result != 500 ) 
		  { cout << "Write failed" << endl ; flag = 0 ; break ; }
		temp1 ++ ;
	      }

	 if (!(k%1000))
	   cout << ".\n";
       }

  cout << "This test completed succesfully \n";
  fs_shutdown () ;
}
