#include <iostream.h>
#include <string.h>
#include "filesys.h"

//---------------------------------------------------------------------------
// test program 3
// 
//  Seek test
//  Seeks to different locations, writes some data and reads back 
//
//--------------------------------------------------------------------------- 
main ( int argc , char **argv ) 
{
  char buf[705] , ch ;
  int fp , slen1 , slen2 , i ;
   
  // Init the filesystem
  fs_init () ;
  fs_create ( "testfile.txt" ) ; 

  // Fill up the buffer with NULLs
  memset ( buf , '\0' , 705 ) ;

  // Write the buffer
  fp = fs_open ( "testfile.txt" , "w" ) ;
  fs_write ( fp , buf , 705 ) ;
  fs_close( fp);

  fp = fs_open( "testfile.txt", "rw");
  //Write at boundaries
  strcpy ( buf , "This program" ) ;
  slen1 = strlen ( buf ) ;
  fs_seek ( fp , 505 ) ;
  fs_write (  fp , buf , slen1 ) ;
  fs_close ( fp ) ;
   
  // Overwrite
  fp = fs_open ( "testfile.txt" , "rw" ) ;
  fs_seek ( fp , 505 ) ;
  strcpy ( buf , "well" ) ;
  slen2 = strlen ( buf ) ;
  fs_write ( fp , buf , slen2 ) ;
  fs_close ( fp ) ;
  
  //Seek in the middle
  fp = fs_open ( "testfile.txt" , "rw" ) ;
  strcpy ( buf , " works " ) ;
  slen2 = strlen ( buf ) ;
  fs_seek ( fp , 505+slen1 ) ;
  fs_write (  fp , buf , slen2 ) ;
  fs_close ( fp ) ;
   
  // Now read back 
  fp = fs_open ( "testfile.txt" , "r" ) ;
  for ( i = 0 ; i < 705 ; i ++ ) 
   {
      fs_read ( fp , &ch , 1 ) ;
      if ( ch != '\0' ) cout << ch ;
   }

  fs_shutdown () ;
}
